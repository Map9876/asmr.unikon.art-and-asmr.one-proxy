const MEDIA_RULESET_ID = 'media_proxy_rules';
const toggle = document.getElementById('mediaToggle');

// 读取当前状态
chrome.declarativeNetRequest.getEnabledRulesets((rulesets) => {
  const mediaEnabled = rulesets.includes(MEDIA_RULESET_ID);
  toggle.checked = mediaEnabled;
});

// 切换时更新规则集
toggle.addEventListener('change', () => {
  const enable = toggle.checked;
  const update = enable
    ? chrome.declarativeNetRequest.updateEnabledRulesets({ enableRulesetIds: [MEDIA_RULESET_ID] })
    : chrome.declarativeNetRequest.updateEnabledRulesets({ disableRulesetIds: [MEDIA_RULESET_ID] });

  update.then(() => {
    // 保存状态
    chrome.storage.local.set({ mediaProxyEnabled: enable });
  }).catch((err) => {
    console.error('Failed to update ruleset:', err);
    toggle.checked = !enable; // 回滚
  });
});
